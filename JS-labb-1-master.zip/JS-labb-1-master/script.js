const startGame = alert('Welcome to Cat Scratch, are you ready to find the cute cat?')

function petHead() {
    prompt('You won! GG EZ, the cat is yours, give it a name.')
}

function petBelly() {
    alert('You lost! the cat hates bellyrubs and scratches you! Try again.')
}



