# Cat Scratch 

## In this adventure you are going to encounter a cute cat, but be aware the cat might scratch you..

<br>

### You are going to get 2 choices when you encounter the cute cat, but remember that one of these choices can decide your whole future, choose well...

<br>

## Links

[Demo Sida](https://empafrontend.github.io/JS-labb-1/)